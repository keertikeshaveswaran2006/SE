# Lab 5 — Static Analysis Issue Log

> Line numbers below refer to the original `vehicle_service.py` supplied for the lab. Exact line numbers can vary if the starter file is reformatted.

| **Issue** | **Type** | **Line(s)** | **Description** | **Fix Approach** |
| --- | --- | ---: | --- | --- |
| Shell command injection risk | Security (high) | 48–49 | `backupRecords` builds a shell command by concatenating `folder` and runs it with `shell=True`. A crafted folder value could execute additional shell commands. | Replace `subprocess.call(..., shell=True)` with `shutil.copy2` and `pathlib.Path`; no shell is invoked. |
| Weak hash algorithm | Security (medium) | 34–35 | MD5 is considered cryptographically broken and should not be used where a stronger digest is available. | Use SHA-256 and retain the existing eight-character identifier format. This changes the generated ID but keeps it deterministic. |
| Mutable default argument | Correctness / maintainability | 12 | `history=[]` is created once and reused between calls, so separate calls can unexpectedly share history. | Default `history` to `None` and create a fresh list inside the function. |
| Overly broad exception | Correctness / maintainability | 21–25 | `except Exception` hides unrelated failures and makes debugging harder. | Use `service_records.get(vehicle_no)` and handle the missing-record case directly. |
| Missing encoding when writing JSON | Reliability / portability | 40–41 | The output file is opened without an explicit encoding. | Use `Path.open(..., encoding="utf-8")` for consistent text handling. |
| Naming and style violations | Style | Throughout | CamelCase function names, inconsistent spacing, long/packed declarations, and missing docstrings reduce readability and trigger style checks. | Rename functions to `snake_case`, apply consistent formatting, add docstrings, and use clear variable names. |
| Unused hard-coded credential | Security / maintainability | 7 | `ADMIN_PASSWORD` is a hard-coded credential and is not used by the program. | Remove the unused constant rather than retaining a misleading hard-coded secret. |
| Manual accumulation loop | Maintainability | 29–32 | The total-cost loop can be expressed more clearly with `sum`. | Replace the loop with `sum(job["cost"] for job in ...)`. |
