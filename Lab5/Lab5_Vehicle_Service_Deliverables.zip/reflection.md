# Lab 5 — Reflection

**Note:** The supplied lab handout describes reflection as a deliverable but does not list the exact four reflection questions. The responses below address four relevant reflection topics; map them to the instructor's exact questions if a separate question sheet was provided.

## 1. What is static code analysis, and why is it useful?

Static code analysis examines source code without running the program. It helps identify potential bugs, insecure patterns, and style problems early. It complements runtime testing: a program may appear to work in a demonstration while still containing risks such as a mutable default argument or shell-command injection.

## 2. What did Pylint, Bandit, and Flake8 each contribute?

Pylint focuses on code quality, naming, documentation, and likely programming mistakes. Bandit focuses on common security risks, such as unsafe shell execution and weak cryptographic hashes. Flake8 checks Python syntax/style conventions, including whitespace and line length. Using all three provides broader coverage than relying on a single tool.

## 3. Which issues were most important, and how were they fixed?

The highest-priority issue was the backup helper's use of `shell=True` with a command assembled from a function argument. Replacing it with `shutil.copy2` avoids shell interpretation. The MD5 digest was replaced with SHA-256. The mutable `history=[]` default was changed to `None` and initialized inside the function, and the broad exception handler was replaced with an explicit missing-record check. Naming, documentation, and file encoding were also improved.

## 4. What did you learn, and what limitations remain?

I learned that static-analysis warnings should be reviewed in context and fixed rather than blindly suppressed. Fixes should be followed by rerunning the tools and testing the program's behavior. Static analysis cannot prove that a program is correct, so manual tests are still needed. The SHA-256 change intentionally changes the job-card ID value, although the ID remains deterministic and eight characters long. The supplied handout does not include the exact reflection questions, and the actual final Pylint/Bandit/Flake8 scores must be confirmed by running those tools in the lab environment.
