"""Vehicle service management system with basic record persistence."""

import hashlib
import json
import shutil
from datetime import date
from pathlib import Path
from typing import Any

SERVICE_RATES = {
    "Oil Change": 1500,
    "Wheel Alignment": 800,
    "General": 2500,
    "Brake Check": 1200,
}

service_records: dict[str, list[dict[str, Any]]] = {}


def add_service(
    vehicle_no: str,
    service_type: str = "General",
    history: list[str] | None = None,
) -> list[str]:
    """Add a service job and append the vehicle number to optional history."""
    cost = SERVICE_RATES.get(service_type, 0)
    entry = {"type": service_type, "cost": cost, "date": str(date.today())}
    service_records.setdefault(vehicle_no, []).append(entry)

    if history is None:
        history = []
    history.append(vehicle_no)
    return history


def cancel_service(vehicle_no: str, service_type: str) -> bool:
    """Cancel all jobs of the requested type for a vehicle."""
    jobs = service_records.get(vehicle_no)
    if jobs is None:
        print("No records for", vehicle_no)
        return False

    remaining = [job for job in jobs if job["type"] != service_type]
    service_records[vehicle_no] = remaining
    return len(remaining) < len(jobs)


def get_total_cost(vehicle_no: str) -> int:
    """Return the total recorded service cost for a vehicle."""
    return sum(job["cost"] for job in service_records.get(vehicle_no, []))


def job_card_id(vehicle_no: str) -> str:
    """Return a short, deterministic job-card identifier for a vehicle."""
    return hashlib.sha256(vehicle_no.encode("utf-8")).hexdigest()[:8]


def busiest_vehicle() -> str | None:
    """Return the vehicle with the most recorded jobs, or None if empty."""
    return max(service_records, key=service_records.get, default=None)


def save_records(file_name: str | Path = "services.json") -> None:
    """Save all service records as formatted JSON."""
    with Path(file_name).open("w", encoding="utf-8") as records_file:
        json.dump(service_records, records_file, indent=2)


def load_records(
    file_name: str | Path = "services.json",
) -> dict[str, list[dict[str, Any]]]:
    """Load service records from a JSON file."""
    with Path(file_name).open(encoding="utf-8") as records_file:
        return json.load(records_file)


def backup_records(folder: str | Path) -> None:
    """Copy services.json into the specified destination directory."""
    source = Path("services.json")
    destination = Path(folder)
    if not source.is_file():
        raise FileNotFoundError(f"Backup source does not exist: {source}")
    shutil.copy2(source, destination)


def main() -> None:
    """Run a short demonstration of the service desk."""
    add_service("KA01AB1234", "Oil Change")
    add_service("KA01AB1234", "Wheel Alignment")
    add_service("KA05XY9876")
    add_service("KA03MN4455", "Brake Check")
    cancel_service("KA05XY9876", "Brake Check")
    cancel_service("KA09ZZ0001", "General")
    cancel_service("KA03MN4455", "Brake Check")
    print("Total for KA01AB1234:", get_total_cost("KA01AB1234"))
    print("Total for KA05XY9876:", get_total_cost("KA05XY9876"))
    print("Job card for KA01AB1234:", job_card_id("KA01AB1234"))
    save_records()
    loaded = load_records()
    print("Vehicles on file:", len(loaded), "| busiest vehicle:", busiest_vehicle())


if __name__ == "__main__":
    main()
